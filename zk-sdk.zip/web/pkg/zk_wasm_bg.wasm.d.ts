/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_keys_free: (a: number, b: number) => void;
export const capabilities: () => [number, number];
export const describe: (a: number, b: number) => [number, number, number, number];
export const keys_proving: (a: number) => [number, number];
export const keys_verifying: (a: number) => [number, number];
export const prove: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const setup: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
export const verify: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
export const witness: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_start: () => void;
